package com.friday.fridayexercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FridayexerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}
